<?php
class regmodel extends CI_Model
{

    public function insertData($data)
    {
        // print_r($data);

        //echo "correctly communicated ";

        $this->load->database();
        // $result=$this->db->insert('sigin_form', $data);
         $this->db->insert('sigin_form', $data);

         return $this->db->insert_id(); 

        // echo $result;

    }


    public function recivedata()
    {
        $this->load->database();
        return $this->db->get('sigin_form')->result();

        // echo '<pre>';
        // print_r($result);
        // echo '</pre>';
    }

    public function displayrecordById($id)
    {
        $this->load->database();
        $query = $this->db->query("select * from sigin_form where id='" . $id . "'");
        return $query->result();
    }

    public function updaterecord($name,$email,$password,$cpassword,$id)
    {
        $this->load->database();
      //  $this->db->update('sigin_form', $datab);

        $this->db->query("update sigin_form SET  name='$name',email='$email',password='$password',cpassword='$cpassword ' 
         where id='".$id."'");
    }


    public function filter($name){
        $this->load->database();
       $query= $this->db-> like('name',$name)->get('sigin_form')->result();
        return $query;

    }


    public function getUser($email){
        $this->load->database();
        return $this->db->where('email', $email)->get('sigin_form')->row();

    }

    public function deleteuser($id){
        $this->load->database();
       return $this->db->query("DELETE FROM sigin_form WHERE id= $id");
    }

    public function userpswdchange($id,$newpswd)
    {
        $this->load->database();
        $this->db->set('password',$newpswd)->set('cpassword',$newpswd)->where('id',$id)->update('sigin_form');


    }

    public function oldpasswordmatch($id,$oldpswd){
    $this->load->database();
       $query= $this->db->where('id', $id)->where('password', $oldpswd)->get('sigin_form');

        if($query->num_rows()>0){
            return true;
        }
        return false;
        
    }

    public function  addUserCategories($user_id,$categorey){
        $this->load->database();
        $this->db->insert('usercategories',array('user_id'=>$user_id,'category'=>$categorey));
       

    }
      }


        

    

?>  