<?php  
#[\AllowDynamicProperties]
class dropdown extends CI_Model{

    public function __construct(){
        parent::__construct();
       
        $this->db=$this->load->database('dropdown',true);
    }

    public function getstate(){
     return  $this->db->get('state')->result();
      
    }

    public function getcity($state_id){
    return $this->db->where('state_id',$state_id)->get('city')->result();
       
    }

    public function getvillage($city_id){
        return $this->db->where('city_id',$city_id)->get('village')->result();
    }

    public function getname($name){
        return $this->db->like('name',$name)->get('country')->result_array();
    }

    public function insertajax($data){
    
      return  $this->db->insert('ajax',$data);
    }
    
}
?>