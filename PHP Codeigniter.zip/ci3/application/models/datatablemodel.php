<?php #[\AllowDynamicProperties]
class datatablemodel extends CI_Model{

    public function __construct(){
        parent::__construct();
     $this->db=$this->load->database('dropdown',true);
        
    }

    public function getbooks(){
      return  $this->db->get('booklist');
    }


}

?>