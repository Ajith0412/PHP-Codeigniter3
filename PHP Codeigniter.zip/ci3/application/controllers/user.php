<?php
class user extends CI_Controller
{

    public function admincontrol()
    {
        $this->load->view('admincontrol');
    }

    public function saveData()
    {

        //    $name= $this->input->post('name');
        //     $email = $this->input->post('email');
        //     $password = $this->input->post('password');
        //     $cpassword = $this->input->post('cpassword');

        extract($_POST);


        $data = [
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'cpassword' => $cpassword


        ];


        if ($password == $cpassword) {


            //echo $name . '-' . $email . '-' . $password . '-' . $cpassword;


            $this->load->model('regmodel');
            $result = $this->regmodel->insertData($data);



            if ($result) {
                // $this->load->view('signup');
                redirect('user/admincontrol');

                //     echo "inserted";
            } else {
                echo "error while inserting";
            }
        } else {
            $pass['errorpas'] = "Please Enter same Password .........!";
            $this->load->view('signup', $pass);
        }
    }

    public function userpage()
    {
        $this->load->model('regmodel');
        $result['view'] = $this->regmodel->recivedata();
        $this->load->view('userpage', $result);

    }

    public function downlode(){
        $this->load->view('downlode');
    }


   
}
?>