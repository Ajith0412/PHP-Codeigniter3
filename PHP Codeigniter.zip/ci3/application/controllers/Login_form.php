<?php
class Login_form extends  CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('regmodel');
    }




    public function index()
    {
        $alert['done'] = "Log_in.........!";
        $this->load->view('login', $alert);
    }

    public function signup()
    {

        $alert['msg'] = "Create Your Account....!";


        $this->load->view('signup', $alert);
    }

    public function saveData()
    {

        //    $name= $this->input->post('name');
        //     $email = $this->input->post('email');
        //     $password = $this->input->post('password');
        //     $cpassword = $this->input->post('cpassword');

        extract($_POST);


        $data = [
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'cpassword' => $cpassword


        ];

        $categories=$this->input->post('categories');


        if ($password == $cpassword) {


            //echo $name . '-' . $email . '-' . $password . '-' . $cpassword;


            $this->load->model('regmodel');
            $user_id = $this->regmodel->insertData($data);

            foreach($categories as $key=>$categorey){
                $this->load->model('regmodel');
             $this->regmodel->addUserCategories($user_id,$categorey);

            }



            if ($user_id) {
                // $this->load->view('signup');
                redirect('http://localhost/ci3/Login_form');

                //     echo "inserted";
            } else {
                echo "error while inserting";
            }
        } else {
            $pass['errorpas'] = "Please Enter same Password .........!";
            $this->load->view('signup', $pass);
        }
    }

    public function viewdata()
    {
        $this->load->model('regmodel');
        $result['view'] = $this->regmodel->recivedata();
        $this->load->view('viewdata', $result);
    }
        
    public function editdata()
    {
        $id = $this->input->get('id');
        $this->load->model('regmodel');
        $result['data'] = $this->regmodel->displayrecordById($id);
        $this->load->view('editdata', $result);

        if ($this->input->post('update')) {

            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $cpassword = $this->input->post('cpassword');

            if ($password == $cpassword) {



                $result['data'] = $this->regmodel->updaterecord($name, $email, $password, $cpassword, $id);
                redirect(base_url('Login_form'));
            }
        }
    }

    public function deleterow(){

        $id = $this->input->get('id');
        $this->load->model('regmodel');
      $result=  $this->regmodel->deleteuser($id);
        if($result)
        {
            redirect(base_url('Login_form/viewdata'));
        }
        else{
            echo "unsucess";
        }

    }


    public function checkresult()
    {
        // if($this->input->get('name')){

        $name = $this->input->get('name');

        if (!empty($name)) {
            $this->load->model('regmodel');
            $post['posts'] = $this->regmodel->filter($name);
            $this->load->view('checkresult', $post);
        } else {
            echo "no record found...../";
        }
    }

    public function login()
    {

        if ($this->session->has_userdata('id')) {

            redirect(base_url('Login_form/adminpage'));
        }
        $this->load->view('login');
    }

    public function loginuser()
    {

        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $this->load->database();

        $this->load->model('regmodel');
        if ($user = $this->regmodel->getUser($email))
        
        {
            if ($user->password == $password) {

               

            $this->session->set_userdata('id', $user->id);
    

                redirect('Login_form/adminpage');
            
            
            } else {
                echo "Login error";
            }
        } else {
            echo "no account found ";
        }
    }


    public function adminpage()
    {
        $this->load->view('admin');
    }

    public function logout()
    {
        $this->session->unset_userdata('id');
        redirect('Login_form/login');
    }

    public function userlogin(){
        $this->load->view('userlogin');
        
    }

    public function changepassword(){
        if($this->session->has_userdata('id')){
        $this->load->view('changepassword');
    
    }
    else{
            echo "no user id found";
    }

    }
    public function updatepassword()
    {
        $oldpswd=$this->input->post('oldpswd');
        $newpswd=$this->input->post('newpswd');

        if($oldpswd!==$newpswd){
            $id = $this->session->userdata('id');

            if($this->regmodel->oldpasswordmatch($id,$oldpswd)){
            $this->load->model('regmodel');
            $this->regmodel->userpswdchange($id,$newpswd);

                redirect(base_url('Login_form/changepassword'));
        }else{
                echo "your old password doed not match";
        }

    }
        else{
            echo "old password and new password can't be same ";
        }
    }
    }



  

