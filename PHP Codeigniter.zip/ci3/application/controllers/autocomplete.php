<?php
class autocomplete extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('dropdown');
        $this->load->database();

    }


public function index(){
    $this->load->view('autocomplete');
}
public function autoload(){

    $query=$this->input->get('query');
    $country_data=$this->dropdown->getname($query);
    
  echo  json_encode($country_data);
}

}
