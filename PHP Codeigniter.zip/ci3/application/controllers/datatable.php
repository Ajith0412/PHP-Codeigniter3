<?php 
class datatable extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->model('datatablemodel');
        $this->db=$this->load->database('dropdown',true);
            $this->load->helper('url');
    }

    public function index(){
        $this->load->view('booklist');
    }

    public function books_data(){
        $draw =$this->input->get('draw');
        $start=$this->input->get('start');
        $length=$this->input->get('length');

        $books=$this->datatablemodel->getbooks();

        $data=array();
        foreach($books->result() as $book){
            $data[]=array(
                $book->booktitle,
                $book->bookprice,
                $book->bookauthor,
                $book->rating,
                $book->publisher

            );

        }
        $output=array(

            'draw'=>$draw,
            'reacordsTotal'=>$books->num_rows(),
            'recordsfiltered'=>$books->num_rows(),
            'data'=>$data
        );
        echo json_encode($output);
        exit();

    }

}
?>