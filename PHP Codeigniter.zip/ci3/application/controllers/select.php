<?php
class select extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('dropdown');
      $this->db=$this->load->database('dropdown',true);
    }

    public function index(){

       $state['state'] =$this->dropdown->getstate();
        $this->load->view('autodrop',$state);
    }

    public function city(){
        $state_id=$this->input->get('state_id');
        $city=$this->dropdown->getcity( $state_id);
        $html='<option value="">Select city</option>';

        foreach($city as $city){
            $html .= '<option value="'.$city->city_id.'">'.$city->city_name.'</option>';
        }
        echo $html;
        
    }


    public function village(){
        $city_id=$this->input->get('city_id');
        $village=$this->dropdown->getvillage($city_id);
        $html='<option value="">Select city</option>';

        foreach($village as $village){
            $html .='<option value="'.$village->village_id.'">'.$village->village_name.'</option>';
        }
        echo $html;
    }

    public function insert(){
      
            $data = array(
                        'name' => $this->input->post('name'),
                        'email'=>$this->input->post('email'),
                        'password'=>$this->input->post('password')
            );

            $this->dropdown->insertajax($data);


          



    }

    
}

?>
