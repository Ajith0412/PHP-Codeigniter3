<?php
class viewajax extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->database();
       
        $this->load->helper('url');
        
       
    }

    public function index(){
        $this->load->view('ajax/home');
    }

 public function insert(){


    $data=array(
        'name'=>$this->input->post("name"),
        'email'=>$this->input->post("email"),
        'password'=>$this->input->post("password")
    );

            $this->load->model('dropdown');
  $result = $this->dropdown->insertajax($data);

 echo json_decode($$result);

        }


 }

?>