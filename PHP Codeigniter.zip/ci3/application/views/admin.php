<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">




    <style>
        a {
            text-decoration: none;
        }

        nav {
            width: 100%;
            max-width: 90%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: auto;
        }

        nav ul {
            width: 200px;

            justify-content: space-around;
            display: flex;
            /* background-color: beige; */
            align-items: center;

        }

        li {
            list-style-type: none;
            font-size: 22px;
            text-transform: uppercase;
        }

        nav ul li button {
            background-color: blue;
            border-radius: 10px;
        }

        li button a {
            font-size: 20px;
            color: white;
        }

        .adminpannel {
            width: 100%;
            display: flex;
            height: 90vh;
        }

        .adminleftcontainer {
            width: 15%;
            background-color: #636c78;

        }

        .adminright {
            width: 85%;
            height: 70vh;
        }

        .adminleftcontainer ul {
            width: 100%;
            max-width: 80%;
            margin: auto;
            height: 67%;
            transform: translateY(25%);

        }

        .adminleftcontainer ul li a {

            color: white;
            line-height: 50px;
            font-size: 20px;
        }

        .adminleftcontainer h2 {
            color: aliceblue;
            text-transform: uppercase;
            text-align: center;
        }

      
    </style>
</head>



<section class="navbar navbar-light bg-light">
        <nav>
            <h2>Dash Borad</h2>

            <ul style="display:flex">
                <li> 
                <li><button><a href="<?= base_url('Login_form/logout/') ?>">Logout</a> </button></li>


            </ul>
        </nav>
    </section>





<?php
    $admin = $this->load->session->userdata('id');
 
    if ($admin == 38) {

      ?>



<section class="adminpannel">
            <div class="adminleftcontainer">

            <h2> User </h2>


                <ul>

                    <li>
                        <a href="">Add User</a>

                    </li>


               
                </ul>

            </div>

            <div class="adminright">
                <section class="vh-70 bg-image">
                    <div class="mask d-flex align-items-center h-70 gradient-custom-3">
                        <div class="container h-70">
                            <div class="row d-flex justify-content-center align-items-center h-70">
                                <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                                    <div class="card" style="border-radius: 15px;">
                                        <div class="card-body p-5">
                                            <h2 class="text-uppercase text-center mb-5">Create an account</h2>

                                            <form action="<?= base_url('user/saveData/') ?>" method="post">

                                                <div class="form-outline mb-4">
                                                    <input type="text" id="form3Example1cg" name="name" class="form-control form-control-lg" />
                                                    <label class="form-label" for="form3Example1cg">Your Name</label>
                                                </div>

                                                <div class="form-outline mb-4">
                                                    <input type="email"  name="email" id="form3Example3cg" class="form-control form-control-lg" />
                                                    <label class="form-label" for="form3Example3cg">Your Email</label>
                                                </div>

                                                <div class="form-outline mb-4">
                                                    <input type="password" name="password" id="form3Example4cg" class="form-control form-control-lg" />
                                                    <label class="form-label" for="form3Example4cg">Password</label>
                                                </div>

                                                <div class="form-outline mb-4">
                                                    <input type="password" name="cpassword" id="form3Example4cdg" class="form-control form-control-lg" />
                                                    <label class="form-label" for="form3Example4cdg">Repeat your password</label>
                                                </div>



                                                <div class="d-flex justify-content-center">
                                                    <button type="submit" class="btn btn-success btn-block btn-lg gradient-custom-4 text-body">ADD User</button>
                                                </div>


                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </section>



 
<?php
}
      elseif($admin==47){?>



<section class="adminpannel">
            <div class="adminleftcontainer">

            <h2> User </h2>


                <ul>

                    <li>
                        <a href="">Add User</a>

                    </li>


               
                </ul>

            </div>

            <div class="adminright">
                <section class="vh-70 bg-image">
                    <div class="mask d-flex align-items-center h-70 gradient-custom-3">
                        <div class="container h-70">
                            <div class="row d-flex justify-content-center align-items-center h-70">
                                <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                                    <div class="card" style="border-radius: 15px;">
                                        <div class="card-body p-5">
                                            <h2 class="text-uppercase text-center mb-5">Create an account</h2>

                                            <form action="<?= base_url('user/saveData/') ?>" method="post">

                                                <div class="form-outline mb-4">
                                                    <input type="text" id="form3Example1cg" name="name" class="form-control form-control-lg" />
                                                    <label class="form-label" for="form3Example1cg">Your Name</label>
                                                </div>

                                                <div class="form-outline mb-4">
                                                    <input type="email"  name="email" id="form3Example3cg" class="form-control form-control-lg" />
                                                    <label class="form-label" for="form3Example3cg">Your Email</label>
                                                </div>

                                                <div class="form-outline mb-4">
                                                    <input type="password" name="password" id="form3Example4cg" class="form-control form-control-lg" />
                                                    <label class="form-label" for="form3Example4cg">Password</label>
                                                </div>

                                                <div class="form-outline mb-4">
                                                    <input type="password" name="cpassword" id="form3Example4cdg" class="form-control form-control-lg" />
                                                    <label class="form-label" for="form3Example4cdg">Repeat your password</label>
                                                </div>



                                                <div class="d-flex justify-content-center">
                                                    <button type="submit" class="btn btn-success btn-block btn-lg gradient-custom-4 text-body">ADD User</button>
                                                </div>


                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </section>



<?php }

 elseif($admin==46){
   //
 redirect(base_url('user/userpage'));
 }

 else{
    echo "You are login  successfully........!";
 }

    