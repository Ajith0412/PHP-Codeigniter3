<head>
<style>
    body{
        width: 100%;
        max-width: 10%;
        margin: auto;
        transform: translateY(35%);
    }
</style>

</head>
<body>

<?php 
if(isset($msg)){
    echo '<h2>'.$msg.'</h2>';
}

?>
    

<form action="<?= base_url('login_form/saveData/')?>" method="post">

<label for="">Name</label> <br>
<input type="text" required name="name">
<br><br>
<label for="">Email</label> <br>
<input type="text" required name="email">
<br><br>

<label for="">Password</label> <br>
<input type="password" required name="password"><br><br>

<label for="">Confirm Password</label> <br>
<input type="password" required name="cpassword"><br><br>


<input type="submit" name="" id="" value="SIGN_IN">

<button><a href="<?= base_url('Login_form/')?>">Log_In</a></button>
<button><a href="<?= base_url('Login_form/getdata')?>">View Data</a></button>

</form>
</body>
