<head>
<style>
    body{
        width: 100%;
        max-width: 10%;
        margin: auto;
        transform: translateY(35%);
    }
</style>

</head>
<body>

<?php 



if(isset($done)){
    echo '<h2>'.$done.'</h2>';
}
?>
    

<form action="">
<label for="">Email</label> <br>
<input type="text" required name="email">
<br><br>

<label for="">Password</label> <br>
<input type="password" required name="password"><br><br>


<input type="submit" name="" id="" value="LogIn">

</form>
<button><a href="<?=base_url('Login_form/signup')?>">SIGN_UP</a></button>
</body>
