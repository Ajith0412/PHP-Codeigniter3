<head><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"></head>

<style>
    .datatable{
        margin: auto;
        border: 1px solid black;
        border-collapse: collapse;
        background-color: aquamarine;
    }

    .datatable tr th{
        border: 1px solid black;
        padding: 7px;
        background-color:azure;
     
    }

    .editform
    {
        width: 100%;
        max-width: 50%;
        margin: auto;
       
        margin-bottom: 10px;
    }

    .in1{
        width: 70%;
        border:1px solid black;
        background: transparent;
        border-radius: 10px;
        height: 40px;
    }

    .in2{
        background: transparent;
        width: 15%;
        height: 40px;
        border-radius: 10px;
        background-color:bisque;
    }
</style>
<body>

 <button class="btn btn-lg btn-block btn-primary"> <a  style="color: white; text-decoration: none;" href="<?= base_url('Login_form/signup')?>">GO Back</a> </button>


 <form class="editform" action="<?=base_url('Login_form/checkresult')  ?> " method="get">
    <input class="in1" type="text" name="name" placeholder="Serach with name " > 
    <input class="in2" type="submit" value="search">
    </form>

<table class="table table-dark table-borderless">
<tr class="table-primary"><th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Password</th>
<th>Confrim password</th>
<th>Edit</th>
<th>Edit</th></tr>

<?php

if(isset($view)) {

        foreach ($view as $row) {
            ?>

<tr>
    <th><?= $row->id; ?></th>
    <th><?= $row->name; ?></th>
    <th><?= $row->email; ?></th>
    <th><?= $row->password; ?></th>
    <th><?= $row->cpassword; ?></th>
    <th>  <a href="<?= base_url('Login_form/editdata/?id=' . $row->id) ?>">Edit</a></th>
    <th>  <a href="<?= base_url('Login_form/deleterow/?id=' . $row->id) ?>">Delete</a></th>

</tr>

<?php

        }
    }
?>




</body>