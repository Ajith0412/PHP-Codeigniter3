<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<style>
  form
  {
    width: 100%;
    
    margin: auto;
    transform: translateY(20%);
    height:20 vh;
    background-color: rgb(96,191,193);

  }

  .mb-3{
    max-width: 30%;
    margin: auto;

  }
  table{
    margin-top: 10vh;
    max-width: 50%;
    margin: auto;
  }

 .data th{
  background-color:rgb( 184, 196, 214);
 }
</style>
</head>

<body>



  


<div><?php if (isset($error)) {
  echo $error;
  

}?>

</div>


<form action="<?=base_url("Upload/do_upload")  ?>"  method="post" enctype="multipart/form-data">
<div class="mb-3">

  <label for="formFile" class="form-label">Uplode File</label>
  <input class="form-control" type="file" id="formFile"  multiple name="files[]"> <br>



<input type="submit" value="Uplode" class="btn btn-secondary">
</div>


</form>

<table class="table table-dark table-borderless">
  <tr>
    <th>File Name</th>
    <th>type</th>
    <th>Size</th>
    <th>Path</th>
  </tr>



  <?php if($data!=null){
    foreach ($data as $data){
    ?>

    
  <tr class="data">
    <th><?= $data['file_name'] ?></th>
    <th><?= $data['file_type'] ?></th>
    <th><?= $data['file_size'] ?></th>
    <th><?= $data['full_path'] ?></th>
  </tr>

  <?php } } ?>


</table>

</body>