<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<style>
 .form{
    width: 100%;
    max-width: 25%;
    margin: auto;
   transform: translateY(45vh);

  }
</style>

</head>

<body>

<div class="dropdown">

<div class="form">
    
<select style="width: 100%;" id="state" class="btn btn-secondary"name="state" >
    <option value="">Select state</option>
    <?php foreach($state as $state){ ?>


        <option value="<?=$state->state_id?>"><?= $state->statename?></option>

   <?php }?>
</select> <br> <br>

<select style="width: 100%;" id="city" class="btn btn-secondary " name="city" >
    <option value="">Select city</option>
</select> <br> <br>

<select style="width: 100%;" id="village" class="btn btn-secondary " name="village" >
    <option value="">Select Village</option>
</select>



</div>

</div>


<script>
    $(document).ready(function(){
        $("#state").change(function(){
            var state_id=$(this).val();

            if(state_id!=""){
                $.ajax({
                    url:"<?=base_url('select/city')?>",
                    type:"get",
                    data:{state_id},
                    success:function(data){
                        $('#city').html(data);
                        $('#village').html('<option value="">Select Village</option>');
                    }

                });

            }else{
                $('#city').html('<option value="">Select city</option>');
                $('#village').html('<option value="">Select Village</option>');
            }

        })


    });

   
        $('#city').change(function(){
            var city_id=$(this).val();

            if(city_id!=""){
                $.ajax({
                    url:"<?=base_url('select/village')?>",
                    method:"get",
                    data:{city_id:city_id},
                    success:function(data){
                        $('#village').html(data);
                    }
                })
            }else{
                $('#village').html('<option value="">Select Village</option>')
            }
        });

</script>
</body>
