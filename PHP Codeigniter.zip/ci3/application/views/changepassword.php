<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

<style>
    form{
        width: 20%;
        margin: auto;
        transform: translateY(1vh);
    }
</style>
</head>




<style>
        a {
            text-decoration: none;
        }

        nav {
            width: 100%;
            max-width: 90%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: auto;
        }

        nav ul {
            width: 200px;

            justify-content: space-around;
            display: flex;
            /* background-color: beige; */
            align-items: center;

        }

        li {
            list-style-type: none;
            font-size: 22px;
            text-transform: uppercase;
        }

        nav ul li button {
            background-color: blue;
            border-radius: 10px;
        }

        li button a {
            font-size: 20px;
            color: white;
        }

        .adminpannel {
            width: 100%;
            display: flex;
            height: 90vh;
        }

        .adminleftcontainer {
            width: 15%;
            background-color: #636c78;

        }

        .adminright {
            width: 85%;
            max-width: 80%;
            margin: auto;
            height: 70vh;
        }

        .adminleftcontainer ul {
            width: 100%;
            max-width: 80%;
            margin: auto;
            height: 100%;
            transform: translateY(25%);

        }

        .adminleftcontainer ul li a {

            color: white;
            line-height: 50px;
            font-size: 20px;
        }

        .adminleftcontainer h2 {
            color: aliceblue;
            text-transform: uppercase;
            text-align: center;
        }


    </style>
</head>
<section class="navbar navbar-light bg-light">
    <nav>
        <h2>Dash Borad</h2>

        <ul style="display:flex">
            <li>
            <li><button class="changepwd"><a href="<?= base_url('Login_form/logout/') ?>">Logout</a> </button></li>


        </ul>
    </nav>
</section>
<section class="adminpannel">
    <div class="adminleftcontainer">

        <h2> User </h2>


        <ul>


            <li>
                <a href="<?= base_url('user/userpage') ?>">View User</a>
            </li>
            <li><a style="font-size: 15px;" href="<?= base_url('Login_form/changepassword') ?>">Change Password</a> </li>

        </ul>

    </div>



<form action="<?= base_url('Login_form/updatepassword')?>" method="post"  enctype="multipart/form-data">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Old Password</label>
    <input type="password" name="oldpswd" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" name="newpswd" class="form-control" id="exampleInputPassword1" required>
  </div>

  <button type="submit" class="btn btn-primary">Submit</button>
</form>