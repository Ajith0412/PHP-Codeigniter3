<html>

<head>


</head>

<body>
    <form id="form" action="">

        <label for="">name</label>
        <input name="name" type="text" id="name"> <br> <br>

        <label for="">Email</label>
        <input name="email" type="email" id="email"> <br> <br>


        <label for="">PassWord</label>
        <input name="password" type="password" id="password"> <br><br>

        <button id="submitbtn">Submit</button>
    </form>

    
<script
  src="https://code.jquery.com/jquery-3.6.3.min.js"
  integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU="
  crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {
            $('#submitbtn').on('click',function () 
            {

                 var name = $('#name').val();
                 var email = $('#email').val();
                var password = $('#password').val();

                $.ajax({
               
                    url: "<?php echo site_url('viewajax/insert')?>",
                    data: 
                    { 
                        name:name,
                        email:email,
                        password:password
                    },
                    type:'POST',
                
                    dataType: 'json',
                    success: function (data) 
                    {
                alert('sucess');
                    }

                })
               

                // alert(name,email,password)
            }
            );
        });
    </script>
</body>

</html>