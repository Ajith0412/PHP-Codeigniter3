<head>
<link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />
<script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
</head>

<body>
    <form class="dropzone"  id="dragupload" action="<?=base_url('Upload/dragupload')?>">

   

</form>

<script>
    Dropzone.options.fileupload = {

        acceptFiles:"image/*",
        maxFilesize:1
    }
</script>
</body>