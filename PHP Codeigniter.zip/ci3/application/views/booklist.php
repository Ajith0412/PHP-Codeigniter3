<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



    <title>Book DataTbble</title>

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
   
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.13.2/datatables.min.css"/>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.13.2/datatables.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/dataTables.bootstrap5.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script type="text/javascript" src="https://cdn.datatables.net/1.13.2/js/dataTables.bootstrap5.min.js"></script>


</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col">
            <h2 style="text-align: center;">Book List
            </h2>

            <table id="book_table" class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <td>Book Title</td>
                        <td>Book Price</td>
                        <td>Book Author</td>
                        <td>Rating</td>
                        <td>Publisher</td>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>

        </div>
        </div>

    </div>
</body>

</html>

<script>
    $(document).ready(function() {
        $('#book_table').DataTable({
            "ajax":{
                url:"<?= site_url('datatable/books_data')?>",
                type:"GET"
            }
        });
    });
</script>