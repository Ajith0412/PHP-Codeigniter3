<head>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.css" rel="stylesheet">
    <style>
        .checkbox{

          
           max-width: 20rem;
           margin: auto;
           font-size: 18px;
           margin-bottom: 10px;
           
        }
    </style>

</head>
<section class="vh-100" style="background-color: #eee;">

    <form action="<?= base_url('login_form/saveData/') ?>" method="post">
        <div class="container h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-lg-12 col-xl-11">
                    <div class="card text-black" style="border-radius: 25px;">
                        <div class="card-body p-md-5">
                            <div class="row justify-content-center">
                                <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                                    <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Sign up</p>


                                    <?php
                                    if (isset($msg)) {
                                        echo '<h3  style="color:blue;
                                         margin-left:80px;">' . $msg . '</h3><br>';
                                    }

                                    ?>

                                    


                                    <form class="mx-1 mx-md-4">

                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input type="text" id="form3Example1c" class="form-control" name="name" required/>
                                                <label class="form-label" for="form3Example1c">Your Name</label>
                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input type="email" id="form3Example3c" class="form-control" name="email" required />
                                                <label class="form-label" for="form3Example3c">Your Email</label>
                                            </div>
                                        </div>

                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-lock fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input type="password" id="form3Example4c" class="form-control" name="password" required />
                                                <label class="form-label" for="form3Example4c">Password</label>
                                            </div>
                                        </div>

                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input type="password" id="form3Example4cd" class="form-control" name="cpassword"  required/>
                                                <label class="form-label" for="form3Example4cd">Repeat your password</label>
                                            </div>
                                     
                                        

                                        </div>

                                        <?php

if (isset($errorpas)) {

    echo '<h6 style="color:red;
    margin-left:40px;">'.$errorpas.'</h6>';
}
?>

<div class="checkbox">
<label class="form-check-label" for="flexCheckChecked"> What You like?</label> <br>
    <input type="checkbox" name="categories[]" value="Movie">
    <label class="form-check-label" for="flexCheckChecked"> Movie</label>&nbsp;
    <input type="checkbox"  name="categories[]" value="Sports">
    <label class="form-check-label" for="flexCheckChecked"> Sports</label>&nbsp;
    <input type="checkbox"  name="categories[]" value="Trip">
    <label class="form-check-label" for="flexCheckChecked"> Trip</label>
    &nbsp; <input type="checkbox"  name="categories[]" value="Reading">
    <label class="form-check-label" for="flexCheckChecked"> Reading</label>
</div>

                                        <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                                            <button type="submit" class="btn btn-primary btn-lg" value="submit">Register</button>
                                            <button style="margin-left: 5px;" class="btn btn-primary btn-lg"><a style="text-decoration: none; color: white;" href="<?= base_url('Login_form/') ?>"> Log_In </a></button>

                                            <button class="btn btn-primary btn-lg" style="margin-left: 5px;"><a style="text-decoration: none; color: white;" href="<?= base_url('Login_form/viewdata/') ?>"> View Data </a></button>
                                        </div>

                                    </form>

                                </div>
                                <div class="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">

                                    <img src="../../../img/draw1.webp" class="img-fluid" alt="Sample image">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </form>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"></script>
</section>